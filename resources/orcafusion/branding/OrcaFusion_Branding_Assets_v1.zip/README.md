OrcaFusion approved branding assets

Copy resources/orcafusion/branding/ into the repository at the same path.

orcafusion-logo.png: full combined logo for splash/About
orcafusion-avatar.png: standalone avatar/master
orcafusion.ico: Windows application icon
orcafusion-avatar-*.png: additional raster sizes

These files have not yet been integrated into executable resources.
